-- MySQL dump 10.13  Distrib 5.5.41, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: fieldpapers
-- ------------------------------------------------------
-- Server version	5.5.41-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `form_fields`
--

DROP TABLE IF EXISTS `form_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `form_fields` (
  `form_id` varchar(8) NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `label` text,
  `type` enum('text','textarea') NOT NULL,
  `choices` blob,
  PRIMARY KEY (`form_id`,`name`),
  KEY `form` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_fields`
--

LOCK TABLES `form_fields` WRITE;
/*!40000 ALTER TABLE `form_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms`
--

DROP TABLE IF EXISTS `forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms` (
  `id` varchar(8) NOT NULL,
  `title` text,
  `form_url` text,
  `http_method` enum('GET','POST') DEFAULT NULL,
  `action_url` text,
  `user_id` varchar(8) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `parsed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms`
--

LOCK TABLES `forms` WRITE;
/*!40000 ALTER TABLE `forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` text,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mbtiles`
--

DROP TABLE IF EXISTS `mbtiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mbtiles` (
  `id` varchar(8) NOT NULL,
  `user_id` varchar(8) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_private` enum('yes','no') DEFAULT 'no',
  `url` varchar(255) DEFAULT NULL,
  `uploaded_file` varchar(255) DEFAULT NULL,
  `min_zoom` int(11) DEFAULT NULL,
  `max_zoom` int(11) DEFAULT NULL,
  `center_zoom` int(11) DEFAULT NULL,
  `center_x_coord` int(11) DEFAULT NULL,
  `center_y_coord` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mbtiles`
--

LOCK TABLES `mbtiles` WRITE;
/*!40000 ALTER TABLE `mbtiles` DISABLE KEYS */;
INSERT INTO `mbtiles` VALUES ('f38fq8p2','6lnc3cfg','2015-02-04 16:53:38','no','http://192.168.33.10/mbtiles.php/malawi_bc_test_1/{Z}/{X}/{Y}.png','malawi_bc_test_1.mbtiles',7,18,13,4876,4413);
/*!40000 ALTER TABLE `mbtiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `print_id` varchar(8) NOT NULL,
  `page_number` varchar(5) NOT NULL,
  `text` text,
  `north` double DEFAULT NULL,
  `south` double DEFAULT NULL,
  `east` double DEFAULT NULL,
  `west` double DEFAULT NULL,
  `zoom` int(10) unsigned DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `preview_url` varchar(255) DEFAULT NULL,
  `country_name` varchar(64) DEFAULT NULL,
  `country_woeid` int(10) unsigned DEFAULT NULL,
  `region_name` varchar(64) DEFAULT NULL,
  `region_woeid` int(10) unsigned DEFAULT NULL,
  `place_name` varchar(128) DEFAULT NULL,
  `place_woeid` int(10) unsigned DEFAULT NULL,
  `user_id` varchar(8) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `composed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`print_id`,`page_number`),
  KEY `print` (`print_id`),
  KEY `user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES ('2kwx9k8z','A1',NULL,30.259056802402,30.259056802402,-97.756343564718,-97.800288875741,5,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:21:15','0000-00-00 00:00:00'),('2kwx9k8z','A2',NULL,30.259056802402,30.259056802402,-97.668452942673,-97.712398253696,5,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:21:15','0000-00-00 00:00:00'),('2kwx9k8z','i',NULL,30.221091452879,30.221091452879,-97.68163653598,-97.787105282434,4,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:21:15','0000-00-00 00:00:00'),('h7tsd836','A1',NULL,30.290930430029,30.244228333207,-97.742996893109,-97.82024451014,15,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/h7tsd836/preview-pA1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:38:13','2015-02-05 03:40:39'),('h7tsd836','A2',NULL,30.290930430029,30.244228333207,-97.665749276077,-97.742996893109,15,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/h7tsd836/preview-pA2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:38:13','2015-02-05 03:40:39'),('h7tsd836','i',NULL,30.323613563832,30.211528537596,-97.650342668014,-97.83573694889,14,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/h7tsd836/preview-pi.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:38:13','2015-02-05 03:40:39'),('m72r8m3h','A1',NULL,30.290930430029,30.244228333207,-97.742996893109,-97.82024451014,15,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/m72r8m3h/preview-pA1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:00:42','2015-02-05 03:03:29'),('m72r8m3h','A2',NULL,30.290930430029,30.244228333207,-97.665749276077,-97.742996893109,15,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/m72r8m3h/preview-pA2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:00:42','2015-02-05 03:03:29'),('m72r8m3h','i',NULL,30.323613563832,30.211528537596,-97.650342668014,-97.83573694889,14,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/m72r8m3h/preview-pi.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:00:42','2015-02-05 03:03:29'),('pc5s5q2b','A1',NULL,30.289818733557,30.245340546032,-97.740936956655,-97.822304446595,15,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/pc5s5q2b/preview-pA1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:28:12','2015-02-05 03:30:46'),('pc5s5q2b','A2',NULL,30.289818733557,30.245340546032,-97.663689339623,-97.745056829563,15,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/pc5s5q2b/preview-pA2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:28:12','2015-02-05 03:30:46'),('pc5s5q2b','i',NULL,30.319567596055,30.215577598435,-97.647836411994,-97.838071543538,14,'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/pc5s5q2b/preview-pi.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:28:12','2015-02-05 03:30:46'),('zpn4cvpm','A1',NULL,30.289818733557,30.245340546032,-97.742374620638,-97.820866782611,15,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/zpn4cvpm/preview-pA1.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:14:03','2015-02-05 03:16:28'),('zpn4cvpm','A2',NULL,30.289818733557,30.245340546032,-97.665127003607,-97.743619165579,15,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/zpn4cvpm/preview-pA2.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:14:03','2015-02-05 03:16:28'),('zpn4cvpm','i',NULL,30.320512406604,30.214632086346,-97.649535859569,-97.836372095963,14,'http://a.tile.openstreetmap.fr/hot/{Z}/{X}/{Y}.png','http://192.168.33.10/files/prints/zpn4cvpm/preview-pi.jpg',NULL,NULL,NULL,NULL,NULL,NULL,'','2015-02-05 03:14:03','2015-02-05 03:16:28');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prints`
--

DROP TABLE IF EXISTS `prints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prints` (
  `id` varchar(8) NOT NULL,
  `title` text,
  `form_id` varchar(8) DEFAULT NULL,
  `north` double DEFAULT NULL,
  `south` double DEFAULT NULL,
  `east` double DEFAULT NULL,
  `west` double DEFAULT NULL,
  `zoom` int(10) unsigned DEFAULT NULL,
  `paper_size` enum('letter','a4','a3') DEFAULT 'letter',
  `orientation` enum('portrait','landscape') DEFAULT 'portrait',
  `layout` enum('half-page','full-page') DEFAULT 'full-page',
  `provider` varchar(255) DEFAULT NULL,
  `pdf_url` varchar(255) DEFAULT NULL,
  `preview_url` varchar(255) DEFAULT NULL,
  `geotiff_url` varchar(255) DEFAULT NULL,
  `atlas_pages` text,
  `country_name` varchar(64) DEFAULT NULL,
  `country_woeid` int(10) unsigned DEFAULT NULL,
  `region_name` varchar(64) DEFAULT NULL,
  `region_woeid` int(10) unsigned DEFAULT NULL,
  `place_name` varchar(128) DEFAULT NULL,
  `place_woeid` int(10) unsigned DEFAULT NULL,
  `user_id` varchar(8) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `composed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `progress` float DEFAULT NULL,
  `private` tinyint(4) NOT NULL,
  `text` mediumtext,
  `cloned` varchar(20) DEFAULT NULL,
  `refreshed` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user_id`),
  KEY `prints_private` (`private`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prints`
--

LOCK TABLES `prints` WRITE;
/*!40000 ALTER TABLE `prints` DISABLE KEYS */;
INSERT INTO `prints` VALUES ('2kwx9k8z',NULL,NULL,30.259056802402,30.259056802402,-97.668452942673,-97.800288875741,NULL,'','landscape','full-page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2015-02-05 03:21:15','0000-00-00 00:00:00',NULL,0,NULL,NULL,NULL),('h7tsd836','My Test Atlas',NULL,30.290930430029,30.244228333207,-97.665749276077,-97.82024451014,NULL,'letter','landscape','full-page',NULL,'http://192.168.33.10/files/prints/h7tsd836/field-paper-h7tsd836.pdf','http://192.168.33.10/files/prints/h7tsd836/preview.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2015-02-05 03:38:13','2015-02-05 03:40:39',0.7,0,NULL,NULL,NULL),('m72r8m3h',NULL,NULL,30.290930430029,30.244228333207,-97.665749276077,-97.82024451014,NULL,'letter','landscape','full-page',NULL,'http://192.168.33.10/files/prints/m72r8m3h/field-paper-m72r8m3h.pdf','http://192.168.33.10/files/prints/m72r8m3h/preview.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2015-02-05 03:00:42','2015-02-05 03:03:29',0.7,0,NULL,NULL,NULL),('pc5s5q2b',NULL,NULL,30.289818733557,30.245340546032,-97.663689339623,-97.822304446595,NULL,'a4','landscape','full-page',NULL,'http://192.168.33.10/files/prints/pc5s5q2b/field-paper-pc5s5q2b.pdf','http://192.168.33.10/files/prints/pc5s5q2b/preview.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2015-02-05 03:28:12','2015-02-05 03:30:46',0.7,0,NULL,NULL,NULL),('zpn4cvpm',NULL,NULL,30.289818733557,30.245340546032,-97.665127003607,-97.820866782611,NULL,'a3','landscape','full-page',NULL,'http://192.168.33.10/files/prints/zpn4cvpm/field-paper-zpn4cvpm.pdf','http://192.168.33.10/files/prints/zpn4cvpm/preview.jpg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2015-02-05 03:14:03','2015-02-05 03:16:28',0.7,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `prints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scan_notes`
--

DROP TABLE IF EXISTS `scan_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scan_notes` (
  `scan_id` varchar(8) NOT NULL,
  `note_number` int(10) unsigned NOT NULL DEFAULT '0',
  `note` text,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `geometry` text,
  `user_id` varchar(8) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`scan_id`,`note_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scan_notes`
--

LOCK TABLES `scan_notes` WRITE;
/*!40000 ALTER TABLE `scan_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `scan_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scans`
--

DROP TABLE IF EXISTS `scans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scans` (
  `id` varchar(8) NOT NULL,
  `print_id` varchar(8) DEFAULT NULL,
  `print_page_number` varchar(5) NOT NULL,
  `print_href` text,
  `min_row` float DEFAULT NULL,
  `min_column` float DEFAULT NULL,
  `min_zoom` int(11) DEFAULT NULL,
  `max_row` float DEFAULT NULL,
  `max_column` float DEFAULT NULL,
  `max_zoom` int(11) DEFAULT NULL,
  `description` text,
  `is_private` enum('yes','no') DEFAULT 'no',
  `will_edit` enum('yes','no') DEFAULT 'yes',
  `has_geotiff` enum('yes','no') DEFAULT 'no',
  `has_geojpeg` enum('yes','no') DEFAULT 'no',
  `has_stickers` enum('yes','no') DEFAULT 'no',
  `base_url` varchar(255) DEFAULT NULL,
  `uploaded_file` varchar(255) DEFAULT NULL,
  `geojpeg_bounds` text,
  `decoding_json` text,
  `country_name` varchar(64) DEFAULT NULL,
  `country_woeid` int(10) unsigned DEFAULT NULL,
  `region_name` varchar(64) DEFAULT NULL,
  `region_woeid` int(10) unsigned DEFAULT NULL,
  `place_name` varchar(128) DEFAULT NULL,
  `place_woeid` int(10) unsigned DEFAULT NULL,
  `user_id` varchar(8) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `decoded` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` int(10) unsigned DEFAULT '0',
  `progress` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user` (`user_id`),
  KEY `print` (`print_id`,`print_page_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scans`
--

LOCK TABLES `scans` WRITE;
/*!40000 ALTER TABLE `scans` DISABLE KEYS */;
INSERT INTO `scans` VALUES ('lghrmm34',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'no','yes','no','no','no',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'6lnc3cfg','2015-02-04 16:53:04','0000-00-00 00:00:00',0,NULL);
/*!40000 ALTER TABLE `scans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(8) NOT NULL,
  `name` varchar(32) DEFAULT NULL,
  `password` varchar(40) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `hash` varchar(32) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activated` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('6lnc3cfg','bc','5b2505039ac5af9e197f5dad04113906a9cf9a2a','brendancol@gmail.com','','2015-02-04 16:47:42','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-02-05 23:46:04
